import pandas as pd
import numpy as np
from faker import Faker
import random

import os
os.makedirs("data/raw", exist_ok=True)

fake = Faker()

data = []

for i in range(500):
    data.append([
        i+1,
        fake.name(),
        fake.country(),
        random.choice(["Approved", "Rejected", "Pending"]),
        random.randint(1000, 50000),
        fake.date_this_year()
    ])

df = pd.DataFrame(data, columns=[
    "Claim_ID",
    "Customer_Name",
    "Country",
    "Status",
    "Amount",
    "Date"
])

output_path = "data/raw/claims_demo.csv"

df.to_csv(output_path, index=False)

print("Dataset Created Successfully")
print(df.shape)